"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  ArrowLeft,
  Search,
  Download,
  Filter,
  BarChart3,
  QrCode,
  Calendar,
  Globe,
  FileText,
  Package,
  User,
  Code,
} from "lucide-react"
import Link from "next/link"

interface QRLog {
  id: string
  refId: string
  type: string
  content: string
  timestamp: string
  ipAddress?: string
}

export default function AdminPage() {
  const [logs, setLogs] = useState<QRLog[]>([])
  const [filteredLogs, setFilteredLogs] = useState<QRLog[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [dateFilter, setDateFilter] = useState<string>("all")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchLogs()
  }, [])

  useEffect(() => {
    filterLogs()
  }, [logs, searchTerm, typeFilter, dateFilter])

  const fetchLogs = async () => {
    try {
      const response = await fetch("/api/qr-logs")
      const data = await response.json()
      setLogs(data.logs || [])
    } catch (error) {
      console.error("Failed to fetch logs:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterLogs = () => {
    let filtered = logs

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (log) =>
          log.refId.toLowerCase().includes(searchTerm.toLowerCase()) ||
          log.content.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Type filter
    if (typeFilter !== "all") {
      filtered = filtered.filter((log) => log.type === typeFilter)
    }

    // Date filter
    if (dateFilter !== "all") {
      const now = new Date()
      const filterDate = new Date()

      switch (dateFilter) {
        case "today":
          filterDate.setHours(0, 0, 0, 0)
          break
        case "week":
          filterDate.setDate(now.getDate() - 7)
          break
        case "month":
          filterDate.setMonth(now.getMonth() - 1)
          break
      }

      filtered = filtered.filter((log) => new Date(log.timestamp) >= filterDate)
    }

    setFilteredLogs(filtered)
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "url":
        return <Globe className="w-4 h-4" />
      case "text":
        return <FileText className="w-4 h-4" />
      case "product":
        return <Package className="w-4 h-4" />
      case "document":
        return <FileText className="w-4 h-4" />
      case "vcard":
        return <User className="w-4 h-4" />
      case "json":
        return <Code className="w-4 h-4" />
      default:
        return <QrCode className="w-4 h-4" />
    }
  }

  const getTypeBadgeColor = (type: string) => {
    switch (type) {
      case "url":
        return "bg-blue-100 text-blue-800"
      case "text":
        return "bg-gray-100 text-gray-800"
      case "product":
        return "bg-green-100 text-green-800"
      case "document":
        return "bg-purple-100 text-purple-800"
      case "vcard":
        return "bg-orange-100 text-orange-800"
      case "json":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const exportLogs = () => {
    const csvContent = [
      ["Reference ID", "Type", "Content", "Timestamp"],
      ...filteredLogs.map((log) => [
        log.refId,
        log.type,
        log.content.replace(/\n/g, " "),
        new Date(log.timestamp).toLocaleString(),
      ]),
    ]
      .map((row) => row.map((cell) => `"${cell}"`).join(","))
      .join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `qr-logs-${new Date().toISOString().split("T")[0]}.csv`
    link.click()
    URL.revokeObjectURL(url)
  }

  const stats = {
    total: logs.length,
    today: logs.filter((log) => {
      const today = new Date()
      const logDate = new Date(log.timestamp)
      return logDate.toDateString() === today.toDateString()
    }).length,
    thisWeek: logs.filter((log) => {
      const weekAgo = new Date()
      weekAgo.setDate(weekAgo.getDate() - 7)
      return new Date(log.timestamp) >= weekAgo
    }).length,
    byType: logs.reduce(
      (acc, log) => {
        acc[log.type] = (acc[log.type] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    ),
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" asChild>
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Generator
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">QR Generation Logs</h1>
              <p className="text-slate-600">Monitor and analyze QR code generation activity</p>
            </div>
          </div>
          <Button onClick={exportLogs} className="bg-blue-600 hover:bg-blue-700">
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Total Generated</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Today</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.today}</p>
                </div>
                <Calendar className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">This Week</p>
                  <p className="text-2xl font-bold text-slate-900">{stats.thisWeek}</p>
                </div>
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600">Most Used</p>
                  <p className="text-2xl font-bold text-slate-900 capitalize">
                    {Object.entries(stats.byType).sort(([, a], [, b]) => b - a)[0]?.[0] || "N/A"}
                  </p>
                </div>
                <QrCode className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-64">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="Search by reference ID or content..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="url">URL</SelectItem>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="product">Product</SelectItem>
                  <SelectItem value="document">Document</SelectItem>
                  <SelectItem value="vcard">vCard</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                </SelectContent>
              </Select>

              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Filter by date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last Week</SelectItem>
                  <SelectItem value="month">Last Month</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Logs Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Generation Logs ({filteredLogs.length} records)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-slate-500">Loading logs...</p>
              </div>
            ) : filteredLogs.length === 0 ? (
              <div className="text-center py-8">
                <QrCode className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">No logs found matching your criteria</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Content Preview</TableHead>
                      <TableHead>Generated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLogs.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="font-mono font-medium">{log.refId}</TableCell>
                        <TableCell>
                          <Badge className={`${getTypeBadgeColor(log.type)} flex items-center gap-1 w-fit`}>
                            {getTypeIcon(log.type)}
                            {log.type.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-md">
                          <p className="truncate text-sm text-slate-600">{log.content}</p>
                        </TableCell>
                        <TableCell className="text-sm text-slate-500">
                          {new Date(log.timestamp).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

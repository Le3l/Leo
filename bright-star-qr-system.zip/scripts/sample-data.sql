-- Sample data for Bright Star QR System
-- This script inserts sample QR generation logs for testing

-- Insert sample QR logs
INSERT INTO qr_logs (ref_id, qr_type, content, created_at, ip_address) VALUES
('BSQR-001001', 'url', 'https://brightstar.ae', '2024-01-15 09:30:00', '192.168.1.100'),
('BSQR-001002', 'product', 'Product: BS-STEEL-001\nMaterial: Steel Rebar\nSize: 12mm x 6m\nFinish: Ribbed\nStock: In Stock', '2024-01-15 10:15:00', '192.168.1.101'),
('BSQR-001003', 'document', 'Document: DOC-2024-001\nRevision: Rev A\nProject: Dubai Marina Tower\nDate: 2024-01-15', '2024-01-15 11:00:00', '192.168.1.102'),
('BSQR-001004', 'text', 'Quality Control Inspection Report - Batch #QC-2024-001\nInspected by: Ahmed Al-Rashid\nDate: 15/01/2024\nStatus: APPROVED', '2024-01-15 14:30:00', '192.168.1.103'),
('BSQR-001005', 'vcard', 'BEGIN:VCARD\nVERSION:3.0\nFN:Mohammed Hassan\nORG:Bright Star Construction Materials LLC\nTITLE:Project Manager\nTEL:+971501234567\nEMAIL:mohammed@brightstar.ae\nEND:VCARD', '2024-01-15 15:45:00', '192.168.1.104'),
('BSQR-001006', 'url', 'https://brightstar.ae/products/concrete-blocks', '2024-01-16 08:20:00', '192.168.1.105'),
('BSQR-001007', 'product', 'Product: BS-CONC-002\nMaterial: Concrete Block\nSize: 200x200x400mm\nFinish: Smooth\nStock: Limited', '2024-01-16 09:10:00', '192.168.1.106'),
('BSQR-001008', 'document', 'Document: SUBMIT-2024-002\nRevision: Rev B\nProject: Abu Dhabi Mall Extension\nDate: 2024-01-16', '2024-01-16 10:30:00', '192.168.1.107'),
('BSQR-001009', 'json', '{"project": "Dubai Marina Tower", "phase": "Foundation", "materials": ["Steel", "Concrete"], "status": "In Progress", "completion": 65}', '2024-01-16 13:15:00', '192.168.1.108'),
('BSQR-001010', 'text', 'Material Delivery Schedule\nDelivery Date: 18/01/2024\nLocation: Dubai Marina Construction Site\nContact: +971501234567', '2024-01-16 16:00:00', '192.168.1.109');

-- Insert sample users (for future authentication)
INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@brightstar.ae', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('mohammed.hassan', 'mohammed@brightstar.ae', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user'),
('ahmed.rashid', 'ahme

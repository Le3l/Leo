#!/bin/bash

# ZeroTrace Chat Backup Script
BACKUP_DIR="/opt/zerotrace-backups"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="zerotrace_backup_$DATE.tar.gz"

echo "🔐 Starting ZeroTrace Chat backup..."

# Create backup directory
mkdir -p $BACKUP_DIR

# Stop services
cd /opt/zerotrace-chat
docker compose stop

# Create backup
tar -czf "$BACKUP_DIR/$BACKUP_FILE" \
  --exclude='data/postgres/pg_wal' \
  --exclude='data/synapse/media_store' \
  data/ config/ element/ .env

# Start services
docker compose start

# Secure delete old backups (keep last 7)
find $BACKUP_DIR -name "zerotrace_backup_*.tar.gz" -type f -mtime +7 -exec shred -vfz -n 3 {} \;

echo "✅ Backup completed: $BACKUP_DIR/$BACKUP_FILE"
echo "🔥 Old backups securely deleted"

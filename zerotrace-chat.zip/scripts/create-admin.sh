#!/bin/bash

# Create Matrix Admin User Script
cd /opt/zerotrace-chat

echo "🔐 Creating Matrix Admin User..."
echo "This will create an admin user for your ZeroTrace Chat system."
echo ""

read -p "Enter admin username: " username
read -s -p "Enter admin password: " password
echo ""

# Create the admin user
docker compose exec synapse register_new_matrix_user \
  -c /data/homeserver.yaml \
  -u "$username" \
  -p "$password" \
  --admin \
  http://localhost:8008

echo "✅ Admin user '$username' created successfully!"
echo "You can now login at: https://le4l.com/chat"

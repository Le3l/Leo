#!/bin/bash

# ZeroTrace Chat Setup Script
# Run this script as root or with sudo privileges

set -e

echo "🔐 ZeroTrace Chat Setup Starting..."

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (use sudo)" 
   exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install required packages
echo "📦 Installing required packages..."
apt install -y docker.io docker-compose-plugin ufw fail2ban certbot python3-certbot-nginx

# Enable and start Docker
systemctl enable docker
systemctl start docker

# Create zerotrace user
echo "👤 Creating zerotrace user..."
useradd -m -s /bin/bash zerotrace
usermod -aG docker zerotrace

# Create directory structure
echo "📁 Creating directory structure..."
mkdir -p /opt/zerotrace-chat/{data/{synapse,postgres},config,element,nginx,ssl,scripts}
chown -R zerotrace:zerotrace /opt/zerotrace-chat

# Generate SSL certificate
echo "🔒 Setting up SSL certificate..."
certbot certonly --standalone -d le4l.com --non-interactive --agree-tos --email admin@le4l.com
cp /etc/letsencrypt/live/le4l.com/fullchain.pem /opt/zerotrace-chat/ssl/le4l.com.crt
cp /etc/letsencrypt/live/le4l.com/privkey.pem /opt/zerotrace-chat/ssl/le4l.com.key
chown -R zerotrace:zerotrace /opt/zerotrace-chat/ssl

# Setup firewall
echo "🔥 Configuring firewall..."
ufw --force enable
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 80/tcp
ufw allow 443/tcp

# Configure fail2ban
echo "🛡️ Configuring fail2ban..."
cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3

[sshd]
enabled = true
port = ssh
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 3
EOF

systemctl enable fail2ban
systemctl restart fail2ban

# Generate Matrix signing key
echo "🔑 Generating Matrix signing key..."
cd /opt/zerotrace-chat
sudo -u zerotrace docker run --rm -v $(pwd)/data/synapse:/data matrixdotorg/synapse:latest generate

# Set secure permissions
chmod 600 /opt/zerotrace-chat/data/synapse/*.key
chmod 600 /opt/zerotrace-chat/.env

echo "✅ ZeroTrace Chat setup completed!"
echo ""
echo "Next steps:"
echo "1. Edit /opt/zerotrace-chat/.env with your secure passwords"
echo "2. Run: cd /opt/zerotrace-chat && docker compose up -d"
echo "3. Create admin user: docker compose exec synapse register_new_matrix_user -c /data/homeserver.yaml http://localhost:8008"
echo "4. Access your chat at: https://le4l.com/chat"

# ZeroTrace Chat - Ultra Secure Matrix Communication System

## 🔐 Overview

ZeroTrace Chat is an ultra-secure, self-hosted Matrix communication system designed for maximum privacy and security. It implements a strict "Zero Trace" policy with no logging, no telemetry, and no metadata leakage.

## 🚀 Quick Start

### Prerequisites
- Ubuntu 20.04+ or Debian 11+ server
- Domain name pointing to your server (le4l.com)
- Root access

### Installation

1. **Run the setup script:**
\`\`\`bash
sudo bash scripts/setup.sh
\`\`\`

2. **Configure environment variables:**
\`\`\`bash
cd /opt/zerotrace-chat
sudo nano .env
# Update all passwords and secrets
\`\`\`

3. **Start the system:**
\`\`\`bash
docker compose up -d
\`\`\`

4. **Create admin user:**
\`\`\`bash
bash scripts/create-admin.sh
\`\`\`

5. **Access your chat:**
Open https://le4l.com/chat in your browser

## 🔒 Security Features

- **End-to-End Encryption**: All messages encrypted by default
- **Zero Logging**: No access logs, error logs, or user activity logs
- **Metadata Suppression**: IP addresses and forwarded headers stripped
- **No Telemetry**: All analytics, metrics, and reporting disabled
- **Hardened Configuration**: Rate limiting, fail2ban, firewall configured
- **Secure SSL**: TLS 1.2+ with strong cipher suites
- **Data Retention**: Automatic message cleanup after 30 days
- **Anonymous Federation**: Federation restricted and IP ranges blacklisted

## 📁 Directory Structure

\`\`\`
/opt/zerotrace-chat/
├── docker-compose.yml      # Main orchestration file
├── .env                    # Environment variables (secure)
├── data/
│   ├── synapse/           # Matrix server data
│   └── postgres/          # Database files
├── config/
│   ├── homeserver.yaml    # Matrix configuration
│   └── log.config         # Logging configuration
├── element/
│   └── config.json        # Element client config
├── nginx/
│   ├── nginx.conf         # Main nginx config
│   └── zerotrace.conf     # Virtual host config
├── ssl/                   # SSL certificates
└── scripts/               # Management scripts
\`\`\`

## 🛠️ Management Commands

### Start/Stop Services
\`\`\`bash
cd /opt/zerotrace-chat
docker compose up -d        # Start all services
docker compose stop         # Stop all services
docker compose restart      # Restart all services
\`\`\`

### Create Users
\`\`\`bash
# Create admin user
bash scripts/create-admin.sh

# Create regular user
docker compose exec synapse register_new_matrix_user \
  -c /data/homeserver.yaml \
  -u username \
  -p password \
  http://localhost:8008
\`\`\`

### Backup System
\`\`\`bash
bash scripts/backup.sh
\`\`\`

### View Logs (Emergency Only)
\`\`\`bash
docker compose logs synapse
docker compose logs element
docker compose logs nginx
\`\`\`

## 🔧 Configuration

### Environment Variables (.env)
- `DOMAIN`: Your domain name
- `POSTGRES_PASSWORD`: Database password (change this!)
- `REGISTRATION_SHARED_SECRET`: Registration secret (change this!)
- `MACAROON_SECRET_KEY`: Macaroon secret (change this!)
- `FORM_SECRET`: Form secret (change this!)

### Security Hardening Checklist
- [ ] Changed all default passwords in .env
- [ ] SSL certificate installed and auto-renewal configured
- [ ] Firewall configured (UFW)
- [ ] Fail2ban configured and running
- [ ] SSH key-only authentication enabled
- [ ] Regular security updates scheduled
- [ ] Backup system tested

## 🚨 Emergency Procedures

### Complete System Reset
\`\`\`bash
cd /opt/zerotrace-chat
docker compose down -v
sudo rm -rf data/*
# Restore from backup or reinitialize
\`\`\`

### Secure Data Destruction
\`\`\`bash
# Securely delete all data
sudo shred -vfz -n 3 data/postgres/*
sudo shred -vfz -n 3 data/synapse/*
sudo shred -vfz -n 3 .env
\`\`\`

## 📞 Support

For security reasons, this system operates with minimal external dependencies. Refer to:
- Matrix Synapse documentation
- Element Web documentation
- Docker Compose documentation

## ⚠️ Security Warnings

1. **Never enable logging** in production
2. **Change all default passwords** before deployment
3. **Use strong, unique passwords** for all accounts
4. **Regularly update** all components
5. **Monitor for unauthorized access** attempts
6. **Backup encryption keys** securely offline
7. **Test disaster recovery** procedures regularly

## 🔐 Zero Trace Compliance

This system is configured to maintain zero traces:
- ✅ No access logs
- ✅ No error logs  
- ✅ No user activity logs
- ✅ No IP address logging
- ✅ No metadata retention
- ✅ No external analytics
- ✅ No telemetry or reporting
- ✅ Automatic data purging
- ✅ Secure credential storage
- ✅ Anonymous proxy headers
